package dswork.core.mybatis.dialect;

/**
 * Dialect for MySQL
 * @author skey
 */
public class MySQLDialect extends LimitOffsetDialect
{
}
